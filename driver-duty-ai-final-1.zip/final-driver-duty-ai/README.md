# Driver Duty AI — Working Full App

Mobile-first FastAPI + SQLite app with Driver Master, Attendance, Fair Duty, Duty History, Monthly Report and optional OpenAI Assistant.

## Run
1. Python 3.11+
2. `pip install -r requirements.txt`
3. Set `OPENAI_API_KEY` as a server environment variable (never in HTML/JS).
4. `uvicorn app.main:app --host 0.0.0.0 --port 8000`
5. Open `http://localhost:8000` on the same device/network.

The AI endpoint is optional; core attendance/duty/report functions work without an API key.
