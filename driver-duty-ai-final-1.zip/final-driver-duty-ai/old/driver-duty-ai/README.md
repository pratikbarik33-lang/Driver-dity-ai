# Driver Duty AI — Mobile Working Demo

Open `index.html` in a mobile browser. Core attendance, driver master, fair duty generation and monthly duty counts work locally using browser storage.

The OpenAI API key must NOT be placed in this HTML. For production AI, connect a secure backend that reads `OPENAI_API_KEY` from server environment variables.
