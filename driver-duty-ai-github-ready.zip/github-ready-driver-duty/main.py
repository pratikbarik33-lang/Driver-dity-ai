import os, sqlite3, json
from datetime import date
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel

BASE=os.path.dirname(__file__)
DB=os.path.join(BASE,'driver_duty.db')
app=FastAPI(title='Driver Duty AI')

def conn():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init():
 c=conn(); c.executescript('''CREATE TABLE IF NOT EXISTS drivers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,shift TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1); CREATE TABLE IF NOT EXISTS attendance(id INTEGER PRIMARY KEY AUTOINCREMENT,driver_id INTEGER,day TEXT,status TEXT,UNIQUE(driver_id,day)); CREATE TABLE IF NOT EXISTS duties(id INTEGER PRIMARY KEY AUTOINCREMENT,driver_id INTEGER,day TEXT);''');
 if c.execute('select count(*) n from drivers').fetchone()['n']==0:
  names=[('Rahul Kumar Singh','A'),('Gopal Sahu','B'),('Gokulanand Bagh','C'),('Ashok Prasad Paswan','A'),('Chotelal Dhila','B'),('Kashi Ram','C'),('Jiva Khandait','A'),('Ranjan Kumar Mahanto','B'),('Sunil Khandait','C'),('Dinesh Kumar Das','A')]
  c.executemany('insert into drivers(name,shift) values(?,?)',names)
 c.commit(); c.close()
init()

class DriverIn(BaseModel): name:str; shift:str='A'
class AttendanceIn(BaseModel): driver_id:int; status:str; day:str|None=None
class GenerateIn(BaseModel): day:str|None=None; number:int=6

@app.get('/api/drivers')
def drivers():
 c=conn(); rows=c.execute('''select d.*, (select count(*) from duties x where x.driver_id=d.id) count from drivers d order by d.name''').fetchall(); c.close(); return [dict(r) for r in rows]
@app.post('/api/drivers')
def add_driver(x:DriverIn):
 c=conn(); cur=c.execute('insert into drivers(name,shift) values(?,?)',(x.name.strip(),x.shift)); c.commit(); row=c.execute('select * from drivers where id=?',(cur.lastrowid,)).fetchone(); c.close(); return dict(row)
@app.get('/api/attendance/{day}')
def attendance(day:str):
 c=conn(); rows=c.execute('''select d.id,d.name,d.shift,coalesce(a.status,'Present') status from drivers d left join attendance a on a.driver_id=d.id and a.day=? where d.active=1 order by d.name''',(day,)).fetchall(); c.close(); return [dict(r) for r in rows]
@app.post('/api/attendance')
def set_att(x:AttendanceIn):
 day=x.day or date.today().isoformat(); c=conn(); c.execute('insert into attendance(driver_id,day,status) values(?,?,?) on conflict(driver_id,day) do update set status=excluded.status',(x.driver_id,day,x.status)); c.commit(); c.close(); return {'ok':True}
@app.post('/api/duty/generate')
def generate(x:GenerateIn):
 day=x.day or date.today().isoformat(); n=max(1,min(x.number,100)); c=conn()
 rows=c.execute('''select d.id,d.name,d.shift,(select count(*) from duties z where z.driver_id=d.id) total from drivers d where d.active=1 and coalesce((select a.status from attendance a where a.driver_id=d.id and a.day=?),'Present')='Present' and not exists(select 1 from duties q where q.driver_id=d.id and q.day=?) order by total,d.name''',(day,day)).fetchall()
 chosen=rows[:n]; c.executemany('insert into duties(driver_id,day) values(?,?)',[(r['id'],day) for r in chosen]); c.commit(); c.close(); return {'day':day,'assigned':[dict(r) for r in chosen]}
@app.get('/api/duties/{day}')
def duties(day:str):
 c=conn(); rows=c.execute('''select d.id,d.name,d.shift from duties x join drivers d on d.id=x.driver_id where x.day=? order by d.name''',(day,)).fetchall(); c.close(); return [dict(r) for r in rows]
@app.get('/api/report/{year}/{month}')
def report(year:int,month:int):
 prefix=f'{year:04d}-{month:02d}-%'; c=conn(); rows=c.execute('''select d.id,d.name,d.shift,(select count(*) from duties x where x.driver_id=d.id and x.day like ?) duties,(select count(*) from attendance a where a.driver_id=d.id and a.day like ? and a.status='Present') present from drivers d where d.active=1 order by duties,d.name''',(prefix,prefix)).fetchall(); c.close(); return [dict(r) for r in rows]
@app.post('/api/ai')
def ai(payload:dict):
 key=os.getenv('OPENAI_API_KEY')
 if not key: raise HTTPException(503,'OPENAI_API_KEY is not configured on the server')
 try:
  from openai import OpenAI
  client=OpenAI(api_key=key)
  model=os.getenv('OPENAI_MODEL','gpt-5.6-luna')
  r=client.responses.create(model=model,input=[{'role':'system','content':'You are Driver Duty AI. Explain attendance and duty-management data clearly. Never override deterministic duty rules.'},{role:'user','content':json.dumps(payload,ensure_ascii=False)}])
  return {'answer':r.output_text}
 except Exception as e: raise HTTPException(500,str(e))

@app.get('/')
def home(): return FileResponse(os.path.join(BASE,'index.html'))
